from re import A
from channels.generic.websocket import AsyncWebsocketConsumer
import json
import asyncio
from asgiref.sync import async_to_sync
from urllib.parse import parse_qs
from asgiref.sync import sync_to_async
from channels.db import database_sync_to_async
import os
import django
from django.db.models import Q   # ✅ added
import random

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'atd.settings')
django.setup()
from asgiref.sync import sync_to_async
from datetime import datetime
from pytz import timezone 
import base64, time
from .models import *
from existing_tables.models import *
from django.conf import settings
from django.utils import timezone as dj_timezone
from datetime import datetime

# --- GLOBAL CONNECTION TRACKER ---
connected_clients = {}

# --- FUEL SAMPLE VALIDATION ---
# Omnicomm LLS reports 0x0FFF (4095) as "sensor error / no valid data". It is a
# status code, not a measurement, so it must never be calibrated or stored --
# the calibration table maps 4095 to full scale, which turned a failed sensor
# into a bogus full-tank reading.
LLS_SENSOR_ERROR_CODE = 4095

# Plausible diesel temperature band. Level and temperature arrive in the same
# LLS frame, so a temperature outside this range means the frame itself is
# corrupt and its level bytes cannot be trusted either.
FUEL_TEMPERATURE_MIN = -20.0
FUEL_TEMPERATURE_MAX = 60.0

# Calibration tables hold decilitres; divide by this to get litres.
FUEL_LEVEL_SCALE = 10.0


def validate_fuel_sample(raw_adc, fuel_temperature=None, points=None):
    """
    Decide whether one raw hardware fuel sample is trustworthy.

    Returns (True, None) when the sample looks real, otherwise
    (False, "<reason>") so the caller can log why it was dropped.
    """
    try:
        adc = float(raw_adc)
    except (TypeError, ValueError):
        return False, f"non-numeric fuel_level {raw_adc!r}"

    if adc >= LLS_SENSOR_ERROR_CODE:
        return False, f"sensor error code {adc:.0f} (LLS 0x0FFF)"

    if fuel_temperature is not None:
        try:
            temp = float(fuel_temperature)
        except (TypeError, ValueError):
            return False, f"non-numeric fuel_temperature {fuel_temperature!r}"
        if not (FUEL_TEMPERATURE_MIN <= temp <= FUEL_TEMPERATURE_MAX):
            return False, f"implausible temperature {temp}C - corrupt frame"

    if points:
        low_code = points[0]["code"]
        high_code = points[-1]["code"]
        if not (low_code <= adc <= high_code):
            return False, f"ADC {adc} outside calibration range {low_code}..{high_code}"

    return True, None

# ---------- Token Verification Helpers ----------
def xor_with_key(data: bytes, key: str) -> bytes:
    key_bytes = key.encode()
    return bytes([b ^ key_bytes[i % len(key_bytes)] for i, b in enumerate(data)])

def digit_sum(imei: str) -> int:
    return sum(int(ch) for ch in imei)

def checksum_twos(imei: str) -> int:
    s = digit_sum(imei) & 0xFF
    return (-s) & 0xFF

def verify_token(token: str, key: str):
    try:
        decrypted = xor_with_key(base64.b64decode(token), key).decode()
        imei, chk, ts = decrypted.split("|")
        expected_chk = checksum_twos(imei)
        return expected_chk == int(chk), {"imei": imei, "checksum": chk, "timestamp": int(ts)}
    except Exception:
        return False, {}

# ---------- Omnicomm TCP Forwarder ----------
OMNICOMM_HOST = "cs.omnicomm.in"
OMNICOMM_PORT = 15349

async def send_to_omnicomm(imei: str, fuel_level):
    """
    Forward a fuel-level reading to the Omnicomm CS server over a
    short-lived TCP connection using the required payload format.
    """
    try:
        try:
            ain_value = int(round(float(fuel_level) * 10))
        except (TypeError, ValueError):
            print(f"[OMNICOMM] Invalid fuel_level={fuel_level!r} for IMEI {imei}; skipping")
            return

        now_str = datetime.now(timezone("Asia/Kolkata")).strftime("%Y-%m-%d %H:%M:%S")

        payload = [{
            "t": str(imei),
            "VD": "ATD",
            "FV": "TSFWAPP0036_0600",
            "ak": 0,
            "AD": 25,
            "PS": "H",
            "v": "a",
            "T": now_str,
            "l": "+23.027725",
            "g": "+75.828285",
            "s": "000.00",
            "CG": "356.21",
            "LC": "00A3",
            "CD": "14687",
            "IV": "3.9",
            "SN": "17",
            "HD": "0.000",
            "o": "0.000",
            "MC": "404",
            "MN": "x10",
            "MV": "19.4",
            "DI": "10000",
            "DO": "00000",
            "AIN": [ain_value, 0],
            "F": ain_value,
            "SID": "1",
            "SDA": "3e01063a5c060000e8",
            "ms": "000000",
            "SS": "31",
            "is": 0,
            "i": 0,
            "p": 1,
            "FN": "226189",
            "VM": "S",
        }]

        data = json.dumps(payload, separators=(",", ":")).encode("utf-8")

        try:
            reader, writer = await asyncio.wait_for(
                asyncio.open_connection(OMNICOMM_HOST, OMNICOMM_PORT),
                timeout=5.0,
            )
        except Exception as e:
            print(f"[OMNICOMM] Connect failed to {OMNICOMM_HOST}:{OMNICOMM_PORT} - {e}")
            return

        try:
            print(f"[OMNICOMM] >>> TCP {OMNICOMM_HOST}:{OMNICOMM_PORT} | IMEI={imei} | fuel_level={fuel_level} | AIN={ain_value}")
            print(f"[OMNICOMM] >>> PAYLOAD: {data.decode('utf-8')}")

            writer.write(data)
            await asyncio.wait_for(writer.drain(), timeout=5.0)
            print(f"[OMNICOMM] Sent fuel_level={fuel_level} (AIN={ain_value}) for IMEI {imei}")

            # ak=1 → expect acknowledgement from server; read whatever it returns
            try:
                ack_bytes = await asyncio.wait_for(reader.read(4096), timeout=5.0)
                if ack_bytes:
                    try:
                        ack_text = ack_bytes.decode("utf-8", errors="replace")
                    except Exception:
                        ack_text = repr(ack_bytes)
                    print(f"[OMNICOMM] <<< ACK for IMEI {imei}: {ack_text}")
                else:
                    print(f"[OMNICOMM] <<< ACK for IMEI {imei}: <empty / connection closed>")
            except asyncio.TimeoutError:
                print(f"[OMNICOMM] <<< ACK timeout for IMEI {imei} (no response in 5s)")
            except Exception as e:
                print(f"[OMNICOMM] <<< ACK read error for IMEI {imei} - {e}")
        except Exception as e:
            print(f"[OMNICOMM] Send failed for IMEI {imei} - {e}")
        finally:
            try:
                writer.close()
                await writer.wait_closed()
            except Exception:
                pass
    except Exception as e:
        print(f"[OMNICOMM] Unexpected error for IMEI {imei}: {e}")


# ---------- WebSocket Consumer ----------
class DispenserControlConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        query_string = self.scope['query_string'].decode('utf8')
        query_params = parse_qs(query_string)

        self.imei_number = query_params.get('imei_number', [None])[0]
        self.token = query_params.get('token', [None])[0]
        self.client_type = query_params.get('client_type', ['unknown'])[0]
        self.room_id = f"room_{self.imei_number}"
        self.channel = self.channel_name


        # Reject if client_type is not hardware or web
        if self.client_type not in ['hardware', 'web']:
            await self.close(code=4002)
            return

        # Token verification
        is_valid = await self.verify_token_and_match_imei(self.token, self.imei_number)
        if not is_valid:
            await self.close(code=4001)
            return

        # Common check: IMEI exists and assigned
        imei_ok = await self.is_imei_assigned(self.imei_number)
        if not imei_ok:
            await self.close(code=4003)
            return

        # Join room and accept connection
        await self.channel_layer.group_add(self.room_id, self.channel_name)
        await self.accept()
        await self.add_connected_client()

        # Send current server epoch time to the connected client
        current_epoch = int(time.time())
        await self.send(text_data=json.dumps({
            "type": 0,
            "machine": self.client_type,
            "epoch_time": current_epoch,
            "message": "connected",
        }))
        print(f"[CONNECT] Sent epoch={current_epoch} to client IMEI={self.imei_number} type={self.client_type}")

        # If hardware client → update connectivity status
        if self.client_type == 'hardware':
            await self.update_connectivity(self.imei_number, "online")
        if self.client_type == 'web':
            print("web client connected")

    async def disconnect(self, close_code):
        await self.channel_layer.group_discard(self.room_id, self.channel_name)
        await self.remove_connected_client()

        # Only update status if hardware disconnects
        if self.client_type == 'hardware':
            await self.update_connectivity(self.imei_number, "offline")
        if self.client_type == 'web':
            print("web client disconnected")

    async def receive(self, text_data=None, bytes_data=None):
        if text_data is not None:
            try:
                data = json.loads(text_data)
            except json.JSONDecodeError:
                await self.send_error_message("Invalid JSON format")
                return

            # Mandatory fields check
            if "type" not in data or "machine" not in data:
                await self.send_error_message("Payload must include 'type' and 'machine'")
                return

            machine = data["machine"]
            msg_type = data["type"]

            if machine not in ["hardware", "web"]:
                await self.send_error_message("Invalid machine type. Allowed: 'hardware', 'web'")
                return

            if machine == "hardware":
                if msg_type == 4:
                    imei = data.get("imei")
                    status = data.get("mstatus")
                    if imei is None or status is None:
                        await self.send_error_message("IMEI and status are required")
                        return

                    try:
                        int_status = int(status)
                    except ValueError:
                        await self.send_error_message("Status must be an integer-compatible value")
                        return
                    await self.update_machine_status(imei, status)
                    await self.update_connectivity(imei, "online")

                    fuel_level = data.get("fuel_level")
                    if fuel_level is not None:
                        # Never relay a sensor error code or a corrupt frame onward.
                        ok, why = validate_fuel_sample(fuel_level, data.get("fuel_temperature"))
                        if ok:
                            asyncio.create_task(send_to_omnicomm(imei, fuel_level))
                        else:
                            print(f"[OMNICOMM SKIP] IMEI {imei}: {why}")

                    # Save fuel reading on change (same behaviour as msg_type 31)
                    fuel_data = ["fuel_level", "fuel_temperature", "fuel_valid"]
                    fuel_data_exists = all(field in data for field in fuel_data)
                    if fuel_data_exists and data["fuel_valid"]:
                        try:
                            fuel_temperature = float(data["fuel_temperature"])
                            fuel_level_val = float(data["fuel_level"])
                            epoch_time = int(data["epoch"]) if data.get("epoch") is not None else int(time.time())
                        except (ValueError, TypeError) as e:
                            await self.send_error_message(f"Field type conversion error: {e}")
                            return
                        await self.update_fuel_readings(imei, fuel_level_val, fuel_temperature, epoch_time, 4, None)
                elif msg_type == 51:
                    imei = data.get("imei")
                    price_status = data.get("price_update_status")
                    volume = data.get("volume")
                    money = data.get("money")
                    ppu_level1 = data.get("ppu_level1")

                    if None in [imei, price_status, volume, money, ppu_level1]:
                        await self.send_error_message("Missing fields for type 51")
                        return
                    
                    if price_status == "success":
                        try:
                            volume_val = float(volume) / 100
                            money_val = float(money)
                            price_val = float(ppu_level1)
                        except ValueError:
                            await self.send_error_message("Invalid number format in volume, money, or ppu_level1")
                            return
                        await self.update_price_fields(imei, volume_val, money_val, price_val)
                    else:
                        print(f"[SKIP PRICE UPDATE] Status = {price_status}")
                elif msg_type == 31:
                    required_fields = [
                        "imei", "time_utc", "lat", "lon", "alt_m",
                        "sats_used", "speed_kmh", "course_deg", "has_fix",
                        "gvr_volume", "gvr_money", "gvr_ppu_level1", "gvr_ppu_level2","epoch"
                    ]
                    obd_data = ["OBDValid","dist_dtc","OBD"]
                    fuel_data = ["fuel_level","fuel_temperature","fuel_valid"]
                    missing_fields = [field for field in required_fields if field not in data]
                    if missing_fields:
                        await self.send_error_message(f"Missing required fields: {', '.join(missing_fields)}")
                        return

                    fuel_data_exists = [field for field in fuel_data if field in data]
                    try:
                        imei = data["imei"]
                        if data["lat"] == None:
                            data["lat"] = 0.0
                        if data["lon"] == None:
                            data["lon"] = 0.0
                        if data["alt_m"] == None:
                            data["alt_m"] = 0.0

                        gps_data = {
                            "time_utc": str(data["time_utc"]),
                            "lat": float(data["lat"]),
                            "lon": float(data["lon"]),
                            "alt_m": float(data["alt_m"]),
                            "sats_used": int(data["sats_used"]),
                            "speed_kmh": float(data["speed_kmh"]),
                            "course_deg": float(data["course_deg"]),
                        }
                        has_fix = bool(data["has_fix"])
                        gvr_volume = int(data["gvr_volume"])
                        gvr_money = int(data["gvr_money"])
                        gvr_ppu_level1 = int(data["gvr_ppu_level1"])
                        epoch_time = int(data["epoch"])

                        if fuel_data_exists and data["fuel_valid"]:
                            fuel_temperature = float(data["fuel_temperature"])
                            fuel_level = float(data["fuel_level"])
                            msg_type = 31
                            transaction_id = None
                            await self.update_fuel_readings(imei, fuel_level, fuel_temperature,epoch_time,msg_type,transaction_id)
                    except (ValueError, TypeError, KeyError) as e:
                        await self.send_error_message(f"Field type conversion error: {e}")
                        return

                    await self.update_gps_coordinates(imei, gps_data, has_fix)
                    await self.update_price_fields(
                        imei=imei,
                        totalizer_reading=gvr_volume / 100.0,
                        amount=gvr_money,
                        live_price=gvr_ppu_level1
                    )

                    obd_fields_exist = all(field in data for field in ["OBDValid", "dist_dtc", "OBD"])
                    obd_valid_flag = False
                    obd_payload = None
                    dist_dtc_val = None
                    if obd_fields_exist and data.get("OBDValid") is True:
                        payload = data.get("OBD")
                        dist_dtc_raw = data.get("dist_dtc")
                        if payload is not None and dist_dtc_raw is not None:
                            try:
                                dist_dtc_val = int(dist_dtc_raw)
                                obd_valid_flag = True
                                obd_payload = payload
                            except (ValueError, TypeError):
                                dist_dtc_val = None

                    await self.save_obd_gps_reading(
                        imei, obd_valid_flag, obd_payload, dist_dtc_val,
                        gps_data, has_fix, epoch_time
                    )
                elif msg_type == 41:
                    required_fields = [
                        "imei", "grade", "volume", "money", "ppu",
                        "status", "mstatus", "epoch", "fuel_time", "transaction_id","gvr_money","gvr_volume"
                    ]
                    fuel_data = ["fuel_level","fuel_temperature","epoch_time","fuel_valid"]
                    gps_fields = ["lat", "lon", "alt_m", "sats_used", "speed_kmh", "course_deg", "has_fix"]
                    obd_fields = ["OBDValid","dist_dtc","OBD"]
                    missing_fields = [f for f in required_fields if f not in data]
                    if missing_fields:
                        await self.send_error_message(f"Missing required fields: {', '.join(missing_fields)}")
                        return
                    fuel_data_exists = [field for field in fuel_data if field in data]
                    gps_data_exists = all(field in data for field in gps_fields)
                    obd_data_exists = all(field in data for field in obd_fields)
                    try:
                        imei = str(data["imei"])
                        volume = float(data["volume"]) / 1000.0
                        money = float(data["money"]) / 1000.0
                        ppu = float(data["ppu"])
                        status = int(data["status"])
                        fuel_time = int(data["fuel_time"])
                        gvr_volume = int(data["gvr_volume"])
                        gvr_money = int(data["gvr_money"])
                        epoch = int(data["epoch"])
                        user_valid = bool(data["user_valid"])
                        user_tag_id = str(data["user_tag_id"])
                        dispense_time = dj_timezone.make_aware(
                            datetime.fromtimestamp(epoch),
                            dj_timezone.get_current_timezone()
                        )
                        transaction_id = str(data["transaction_id"])
                        if fuel_data_exists and data["fuel_valid"]:
                            fuel_temperature = float(data["fuel_temperature"])
                            fuel_level = float(data["fuel_level"])
                            epoch_time = int(data["epoch_time"])
                            msg_type = 41
                            await self.update_fuel_readings(imei, fuel_level, fuel_temperature,epoch_time,msg_type,transaction_id)

                        gps_data_ending = None
                        has_fix = False
                        if gps_data_exists:
                            if data["lat"] == None:
                                data["lat"] = 0.0
                            if data["lon"] == None:
                                data["lon"] = 0.0
                            if data["alt_m"] == None:
                                data["alt_m"] = 0.0
                            gps_data_ending = {
                                "lat": float(data["lat"]),
                                "lon": float(data["lon"]),
                                "alt_m": float(data["alt_m"]),
                                "sats_used": int(data["sats_used"]),
                                "speed_kmh": float(data["speed_kmh"]),
                                "course_deg": float(data["course_deg"]),
                            }
                            has_fix = bool(data["has_fix"])

                        obd_payload = None
                        obd_valid = False
                        dist_dtc_val = None
                        if obd_data_exists and data.get("OBDValid") is True:
                            obd_payload = data.get("OBD")
                            dist_dtc_raw = data.get("dist_dtc")
                            if obd_payload is not None and dist_dtc_raw is not None:
                                try:
                                    dist_dtc_val = int(dist_dtc_raw)
                                    obd_valid = True
                                except (ValueError, TypeError):
                                    dist_dtc_val = None

                    except (ValueError, TypeError, KeyError) as e:
                        await self.send_error_message(f"Field type conversion error: {e}")
                        return

                    dispense_transaction_result = await self.update_dispense_transaction_details(
                        transaction_id=transaction_id,
                        imei=imei,
                        ppu=ppu,
                        volume=volume,
                        money=money,
                        dispense_time=dispense_time,
                        fuel_time=fuel_time,
                        gvr_money=gvr_money,
                        gvr_volume=gvr_volume,
                        user_valid=user_valid,
                        user_tag_id =user_tag_id
                    )
                    request_status_result = await self.update_request_status_from_status_code(transaction_id,imei, status)
                    if "error" in dispense_transaction_result:
                        await self.send_error_message(dispense_transaction_result["error"])
                        return
                    else:
                        print(f"[DISPENSE TRANSACTION UPDATED] TXN={transaction_id} → Status={dispense_transaction_result['request_status']} from code={status}")
                    if "error" in request_status_result:
                        await self.send_error_message(request_status_result["error"])
                        return
                    else:
                        if str(transaction_id).upper().startswith("VIN"):
                            self.send_data({"type":99,"machine": "hardware","data":transaction_id})
                            vin_update = await self.mark_vin_vehicle_status_true(transaction_id)
                            self.send_data({"type":99,"machine": "hardware","data":vin_update})
                            if "error" in vin_update:
                                await self.send_error_message(vin_update["error"])
                                return
                            else:
                                self.send_data({"type":99,"machine": "hardware","set to true":transaction_id})
                                print(f"[VIN FLAG] TXN={transaction_id} VIN_Vehicle.status set to True")

                        print(f"[REQUEST STATUS UPDATED] TXN={transaction_id} → Status={request_status_result['request_status']} from code={status}")

                    # Save GPS ending + OBD data to the transaction record
                    if gps_data_ending is not None or obd_valid:
                        await self.save_gps_ending_and_obd_to_transaction(
                            transaction_id=transaction_id,
                            imei=imei,
                            gps_data_ending=gps_data_ending,
                            obd_valid=obd_valid,
                            obd_data=obd_payload,
                            dist_dtc=dist_dtc_val,
                        )

                    # Save to VehicleOBDAndGPSReadings history table
                    obd_valid_flag = bool(obd_valid and dist_dtc_val is not None)
                    if obd_valid_flag or gps_data_exists:
                        await self.save_obd_gps_reading(
                            imei,
                            obd_valid_flag,
                            obd_payload if obd_valid_flag else None,
                            dist_dtc_val if obd_valid_flag else None,
                            gps_data_ending or {},
                            has_fix,
                            epoch,
                        )
                elif msg_type == 61:
                    # User-tag + IMEI same-customer validation
                    # Hardware payload (in):
                    #   { "type": 61, "imei": "...", "user_tag_id": "A_0000006806" }
                    # Backend reply (out) to hardware uses type 6
                    required_fields = ["imei", "user_tag_id"]
                    missing_fields = [f for f in required_fields if f not in data]
                    if missing_fields:
                        await self.send_data({
                            "type": 6,
                            "status": "error",
                            "error": f"Missing required fields: {', '.join(missing_fields)}",
                        })
                        return

                    try:
                        imei = str(data["imei"]).strip()
                        raw_tag = str(data["user_tag_id"]).strip()
                    except (ValueError, TypeError, KeyError) as e:
                        await self.send_data({
                            "type": 6,
                            "status": "error",
                            "error": f"Field type conversion error: {e}",
                        })
                        return

                    # Parse "A_NNNNNNNN..." → user_id (supports IDs > 10000, any length)
                    if not raw_tag.startswith("A_"):
                        await self.send_data({
                            "type": 6,
                            "status": "error",
                            "imei": imei,
                            "user_tag_id": raw_tag,
                            "error": f"Invalid user_tag_id '{raw_tag}'. Expected format 'A_<digits>'.",
                        })
                        return

                    digits = raw_tag[2:].lstrip("0") or "0"
                    if not digits.isdigit():
                        await self.send_data({
                            "type": 6,
                            "status": "error",
                            "imei": imei,
                            "user_tag_id": raw_tag,
                            "error": f"Invalid user_tag_id '{raw_tag}': trailing portion must be numeric.",
                        })
                        return
                    user_id = int(digits)

                    # DB validation
                    result = await self.validate_user_tag_with_dispenser(user_id, imei)
                    if "error" in result:
                        await self.send_data({
                            "type": 6,
                            "status": "error",
                            "imei": imei,
                            "user_tag_id": raw_tag,
                            "user_id": user_id,
                            "error": result["error"],
                        })
                        return

                    # Success → reply with type 6
                    await self.send_data({
                        "type": 6,
                        "status": "valid",
                        "imei": imei,
                        "user_tag_id": raw_tag,
                        "user_id": result["user_id"],
                        "user_name": result["user_name"],
                        "customer_id": result["customer_id"],
                        "customer_name": result["customer_name"],
                        "message": "User and dispenser belong to the same customer.",
                    })
                    print(
                        f"[USER-TAG VALIDATION] in=61 out=6 OK tag={raw_tag} "
                        f"user_id={user_id} IMEI={imei} customer_id={result['customer_id']}"
                    )

                elif msg_type == 71:
                    # Asset-tag + User-tag POC validation
                    #   AND create a Full Tank Mode transaction on success.
                    # Hardware payload (in):
                    #   { "type": 62, "imei": "...",
                    #     "asset_tag_id": "...", "user_tag_id": "A_0000006806" }
                    # Backend reply (out):
                    #   - On success: type=1 start-dispense payload (below)
                    #   - On failure: type=7 with "status":"error"
                    required_fields = ["imei", "asset_tag_id", "user_tag_id"]
                    missing_fields = [f for f in required_fields if f not in data]
                    if missing_fields:
                        await self.send_data({
                            "type": 7,
                            "status": "error",
                            "error": f"Missing required fields: {', '.join(missing_fields)}",
                        })
                        return

                    try:
                        imei = str(data["imei"]).strip()
                        asset_tag_id = str(data["asset_tag_id"]).strip()
                        raw_tag = str(data["user_tag_id"]).strip()
                    except (ValueError, TypeError, KeyError) as e:
                        await self.send_data({
                            "type": 7,
                            "status": "error",
                            "error": f"Field type conversion error: {e}",
                        })
                        return

                    # Parse "A_NNNNNNNN..." → user_id (handles >10000, any length)
                    if not raw_tag.startswith("A_"):
                        await self.send_data({
                            "type": 7,
                            "status": "error",
                            "imei": imei,
                            "asset_tag_id": asset_tag_id,
                            "user_tag_id": raw_tag,
                            "error": f"Invalid user_tag_id '{raw_tag}'. Expected format 'A_<digits>'.",
                        })
                        return

                    digits = raw_tag[2:].lstrip("0") or "0"
                    if not digits.isdigit():
                        await self.send_data({
                            "type": 7,
                            "status": "error",
                            "imei": imei,
                            "asset_tag_id": asset_tag_id,
                            "user_tag_id": raw_tag,
                            "error": f"Invalid user_tag_id '{raw_tag}': trailing portion must be numeric.",
                        })
                        return
                    user_id = int(digits)

                                        # 1) Validate + resolve all DB references (NO row created yet)
                    resolved = await self.validate_and_resolve_full_tank_context(
                        imei=imei,
                        asset_tag_id=asset_tag_id,
                        user_id=user_id,
                        user_tag_raw=raw_tag,
                    )
                    if "error" in resolved:
                        await self.send_data({
                            "type": 7,
                            "status": "error",
                            "imei": imei,
                            "asset_tag_id": asset_tag_id,
                            "user_tag_id": raw_tag,
                            "user_id": user_id,
                            "error": resolved["error"],
                        })
                        return

                    # 2) Send the type=1 start-dispense payload to hardware FIRST
                    await self.send_data({
                        "type": 1,
                        "imei": imei,
                        "transaction_id": resolved["transaction_id"],
                        "machine_index": 1,
                        "grade_index": 1,
                        "nozzle_index": 1,
                        "rfid_valid": True,
                        "vehicle_tag_id": asset_tag_id,
                        "preset_state": 0,
                        "preset_volume": 0,
                        "preset_amount": 0,
                        "machine": "web",
                        "user_valid": False,
                        "user_tag": raw_tag,
                    })
                    print(
                        f"[ASSET-USER POC] in=71 out=1 SENT TXN={resolved['transaction_id']} "
                        f"IMEI={imei} asset_id={resolved['asset_id']} user_id={user_id} "
                        f"customer_id={resolved['customer_id']}"
                    )

                    # 3) THEN create the Full Tank Mode request row
                    create_result = await self.create_full_tank_request_row(resolved)
                    if "error" in create_result:
                        # Hardware already told to start — log loudly; do NOT try
                        # to retract here. Adjust later if you need a cancel cmd.
                        print(
                            f"[ASSET-USER POC][CRITICAL] DB write FAILED after start sent. "
                            f"TXN={resolved['transaction_id']} IMEI={imei} "
                            f"reason={create_result['error']}"
                        )
                    else:
                        print(
                            f"[ASSET-USER POC] TXN row created id={create_result['row_id']} "
                            f"TXN={resolved['transaction_id']}"
                        )




                elif msg_type == 11:
                    required_fields = [
                        "imei", "transaction_id", "preset_state", "preset_volume_req", "preset_amount_req",
                        "rfid_valid", "vehicle_tag_id","user_valid","user_tag_id","live_preset_volume", "live_preset_price",
                        "fuel_state", "status"
                    ]
                    if data.get("status") == 200:
                        required_fields += ["gvr_money", "gvr_volume","epoch", "lat", "lon", "alt_m", "sats_used", "speed_kmh", "course_deg"]
                    missing_fields = [f for f in required_fields if f not in data]
                    if missing_fields:
                        await self.send_error_message(f"Missing required fields: {', '.join(missing_fields)}")
                        return
                    try:
                        imei = str(data["imei"])
                        transaction_id = str(data["transaction_id"])
                        preset_state = int(data["preset_state"])
                        preset_volume_req = float(data["preset_volume_req"])
                        preset_amount_req = float(data["preset_amount_req"])
                        rfid_valid = bool(data["rfid_valid"])
                        user_valid = bool(data["user_valid"])
                        user_tag_id = str(data["user_tag_id"])
                        vehicle_tag_id = str(data["vehicle_tag_id"])
                        live_preset_volume = float(data["live_preset_volume"])
                        live_preset_price = float(data["live_preset_price"])
                        fuel_state = bool(data["fuel_state"])
                        status = int(data["status"])
                    except (ValueError, TypeError, KeyError) as e:
                        await self.send_error_message(f"Field type conversion error: {e}")
                        return
                    if status == 200:
                        try:
                            totalizer_volume_starting = float(data["gvr_volume"]/100)
                            totalizer_price_starting = float(data["gvr_money"])
                            lat = 0.0 if data["lat"] is None else float(data["lat"])
                            lon = 0.0 if data["lon"] is None else float(data["lon"])
                            alt_m = 0.0 if data["alt_m"] is None else float(data["alt_m"])

                            gps_coordinates_starting = {
                                "epoch" : int(data["epoch"]),
                                "lat": lat,
                                "lon": lon,
                                "alt_m": alt_m,
                                "sats_used": int(data["sats_used"]),
                                "speed_kmh": float(data["speed_kmh"]),
                                "course_deg": float(data["course_deg"]),
                            }
                            await self.save_totalizer_and_gps_starting_with_validation(transaction_id, imei, totalizer_volume_starting, totalizer_price_starting, gps_coordinates_starting)
                        except (ValueError, TypeError, KeyError) as e:
                            await self.send_error_message(f"GPS/Totalizer parsing error: {e}")
                            return
                    result = await self.update_transaction_log(data)
                    request_status_result = await self.update_request_status_from_status_code(transaction_id, imei, status)
                    if "error" in request_status_result:
                        await self.send_error_message(request_status_result["error"])
                        return
                    else:
                        print(f"[REQUEST STATUS UPDATED] TXN={transaction_id} → Status={request_status_result['request_status']} from code={status}")

                    if "error" in result:
                        await self.send_error_message(result["error"])
                        return
                    else:
                        print(f"[PRESET LOG] Updated for TXN={transaction_id} IMEI={imei}")
                else:
                    pass
            await self.channel_layer.group_send(
                self.room_id,
                {
                    "type": "dispenser.text",
                    "text": text_data,
                    "sender_channel_name": self.channel_name,
                },
            )
        elif bytes_data is not None:
            await self.channel_layer.group_send(
                self.room_id,
                {
                    "type": "dispenser.bytes",
                    "bytes": bytes_data,
                    "sender_channel_name": self.channel_name,
                },
            )
        
    async def dispenser_text(self, event):
        if event["sender_channel_name"] != self.channel_name:
            await self.send(text_data=event["text"])

    async def dispenser_bytes(self, event):
        if event["sender_channel_name"] != self.channel_name:
            await self.send(bytes_data=event["bytes"])

    async def add_connected_client(self):
        imei = self.imei_number
        client_type = self.client_type
        connected_clients.setdefault(imei, {}).setdefault(client_type, [])
        if self.channel_name not in connected_clients[imei][client_type]:
            connected_clients[imei][client_type].append(self.channel_name)

    async def remove_connected_client(self):
        imei = self.imei_number
        client_type = self.client_type
        if imei in connected_clients and client_type in connected_clients[imei]:
            try:
                connected_clients[imei][client_type].remove(self.channel_name)
            except ValueError:
                pass

    async def send_error_message(self, error_message):
        await self.send(text_data=json.dumps({"error": error_message}))

    async def send_data(self, data):
        await self.send(text_data=json.dumps(data))

    @sync_to_async
    def verify_token_and_match_imei(self, token: str, given_imei: str) -> bool:
        key = "atd_shared_secret_key"
        valid, data = verify_token(token, key)
        return valid and data.get("imei") == given_imei

    @database_sync_to_async
    def is_imei_assigned(self, imei: str) -> bool:
        try:
            dispenser = DispenserUnits.objects.get(imei_number=imei)
            return dispenser.assigned_status is True
        except DispenserUnits.DoesNotExist:
            return False

    @database_sync_to_async
    def update_connectivity(self, imei: str, status: str):
        try:
            dispenser = DispenserUnits.objects.get(imei_number=imei)
        except DispenserUnits.DoesNotExist:
            return
        is_online = (status == "online")
        dispenser.connectivity_status = is_online
        dispenser.save(update_fields=["connectivity_status"])
        Dispenser_Gun_Mapping_To_Customer.objects.filter(
            dispenser_unit_id=dispenser.id
        ).update(connectivity_status=is_online)
        Dispenser_Gun_Mapping_To_Vehicles.objects.filter(
            dispenser_unit_id=dispenser.id
        ).update(connectivity_status=is_online)




    @database_sync_to_async
    def update_machine_status(self, imei: str, status: str):
        try:
            dispenser = DispenserUnits.objects.get(imei_number=imei)
            affected = Dispenser_Gun_Mapping_To_Customer.objects.filter(
                dispenser_unit_id=dispenser.id
            ).update(machine_status=status)
            vehicle_count = Dispenser_Gun_Mapping_To_Vehicles.objects.filter(
                dispenser_unit_id=dispenser.id
            ).update(machine_status=status)
        except DispenserUnits.DoesNotExist:
            print(f"[ERROR] IMEI {imei} not found in DispenserUnits for machine status update")

    @database_sync_to_async
    def update_price_fields(self, imei, totalizer_reading, amount, live_price=None):
        # live_price is only refreshed from the hardware when
        # settings.UPDATE_LIVE_PRICE_FROM_WEBSOCKET is True. When it is False the
        # column is left out of the UPDATE entirely, so the existing value stands.
        try:
            dispenser = DispenserUnits.objects.get(imei_number=imei)
            update_fields = {
                "live_totalizer_reading": totalizer_reading,
                "live_total_reading_amount": amount,
            }
            if getattr(settings, "UPDATE_LIVE_PRICE_FROM_WEBSOCKET", False):
                update_fields["live_price"] = live_price

            Dispenser_Gun_Mapping_To_Customer.objects.filter(
                dispenser_unit_id=dispenser.id
            ).update(**update_fields)

            Dispenser_Gun_Mapping_To_Vehicles.objects.filter(
                dispenser_unit_id=dispenser.id
            ).update(**update_fields)
        except DispenserUnits.DoesNotExist:
            print(f"[ERROR] IMEI {imei} not found for price update")

    @database_sync_to_async
    def validate_user_tag_with_dispenser(self, user_id, imei):
        """
        Returns:
            {"error": "..."}  on any failure
            {
              "user_id": int, "user_name": str,
              "customer_id": int, "customer_name": str
            } on success
        """
        # 1) User exists?
        try:
            user = Users.objects.get(id=user_id)
        except Users.DoesNotExist:
            return {"error": f"User with id {user_id} (from tag) does not exist."}

        # 2) Dispenser exists?
        try:
            dispenser = DispenserUnits.objects.get(imei_number=imei)
        except DispenserUnits.DoesNotExist:
            return {"error": f"Dispenser with IMEI {imei} does not exist."}

        # 3) Customer(s) the dispenser is mapped to
        dispenser_customer_ids = set(
            Dispenser_Gun_Mapping_To_Customer.objects
            .filter(dispenser_unit_id=dispenser.id)
            .values_list("customer", flat=True)
            .distinct()
        )
        if not dispenser_customer_ids:
            return {"error": f"Dispenser IMEI {imei} is not mapped to any customer."}

        # 4) Customer(s) the user belongs to (via PointOfContacts)
        user_customer_ids = set(
            PointOfContacts.objects
            .filter(user_id=user_id, belong_to_type="Customer")
            .values_list("belong_to_id", flat=True)
            .distinct()
        )
        if not user_customer_ids:
            return {"error": f"User {user_id} is not associated with any customer."}

        # 5) Same-customer check (intersection)
        shared = user_customer_ids & dispenser_customer_ids
        if not shared:
            return {
                "error": (
                    f"User {user_id} and dispenser IMEI {imei} "
                    f"do not belong to the same customer."
                )
            }

        customer_id = next(iter(shared))
        try:
            customer = Customers.objects.get(id=customer_id)
            customer_name = customer.name
        except Customers.DoesNotExist:
            customer_name = ""

        return {
            "user_id": user.id,
            "user_name": user.name,
            "customer_id": customer_id,
            "customer_name": customer_name,
        }

    @database_sync_to_async
    def validate_and_resolve_full_tank_context(self, imei, asset_tag_id, user_id, user_tag_raw):
        """
        Validate user/asset/dispenser/POC and resolve every field needed to
        (a) reply to hardware with the start-dispense payload, and
        (b) create the RequestFuelDispensingDetails row afterwards.
        Does NOT write to the DB.

        Returns {"error": "..."} on failure, otherwise a dict containing all
        resolved fields + a freshly generated transaction_id.
        """
        # 1) User exists?
        try:
            user = Users.objects.get(id=user_id)
        except Users.DoesNotExist:
            return {"error": f"User with id {user_id} (from tag) does not exist."}

        # 2) Asset exists by tag_id? (tag_id is not unique → pick latest)
        asset = Assets.objects.filter(tag_id=asset_tag_id).order_by("-id").first()
        if asset is None:
            return {"error": f"Asset with tag_id '{asset_tag_id}' does not exist."}

        customer_id = asset.customer_id
        if not customer_id:
            return {"error": f"Asset '{asset.name}' has no customer assigned."}

        # 3) Dispenser exists by IMEI?
        try:
            dispenser_unit = DispenserUnits.objects.get(imei_number=imei)
        except DispenserUnits.DoesNotExist:
            return {"error": f"Dispenser with IMEI {imei} does not exist."}

        # 4) Is the user a POC of the asset's customer?
        is_poc = PointOfContacts.objects.filter(
            user_id=user_id,
            belong_to_type="customer",
            belong_to_id=customer_id,
        ).exists()
        if not is_poc:
            return {
                "error": (
                    f"User {user_id} is not a Point of Contact for asset "
                    f"'{asset.name}' (customer {customer_id})."
                )
            }

        # 5) Dispenser must be mapped to the asset's customer
        mapping = Dispenser_Gun_Mapping_To_Customer.objects.filter(
            dispenser_unit_id=dispenser_unit.id,
            customer=customer_id,
        ).first()
        if mapping is None:
            return {
                "error": (
                    f"Dispenser IMEI {imei} is not mapped to customer "
                    f"{customer_id} (asset's customer)."
                )
            }

        # 6) Delivery-location mapping for this dispenser-gun mapping
        dl_mapping = DeliveryLocation_Mapping_DispenserUnit.objects.filter(
            dispenser_gun_mapping_id=mapping.id,
        ).first()
        if dl_mapping is None:
            return {
                "error": (
                    f"No delivery-location mapping found for dispenser-gun "
                    f"mapping {mapping.id}."
                )
            }
        delivery_location_id = dl_mapping.delivery_location_id
        du_accessible = dl_mapping.DU_Accessible_delivery_locations or []

        try:
            delivery_location_name = DeliveryLocations.objects.get(
                id=delivery_location_id
            ).name
        except DeliveryLocations.DoesNotExist:
            delivery_location_name = ""

        # 7) Customer details
        try:
            customer = Customers.objects.get(id=customer_id)
            customer_name = customer.name
            customer_email = customer.email
            customer_phone = customer.mobile
        except Customers.DoesNotExist:
            customer_name, customer_email, customer_phone = "", "", ""

        # 8) Generate a unique TXN id (TXN + 12 digits)
        while True:
            txn_id = "TXN" + str(random.randint(100000000000, 999999999999))
            if not RequestFuelDispensingDetails.objects.filter(
                transaction_id=txn_id
            ).exists():
                break

        return {
            "transaction_id": txn_id,
            "user_id": user.id,
            "user_name": user.name,
            "user_email": user.email,
            "user_phone": user.mobile,
            "user_tag_id": user_tag_raw,
            "dispenser_gun_mapping_id": mapping.id,
            "dispenser_serialnumber": dispenser_unit.serial_number,
            "dispenser_imeinumber": dispenser_unit.imei_number,
            "delivery_location_id": delivery_location_id,
            "delivery_location_name": delivery_location_name,
            "DU_Accessible_delivery_locations": du_accessible,
            "customer_id": customer_id,
            "customer_name": customer_name,
            "customer_email": customer_email,
            "customer_phone": customer_phone,
            "asset_id": asset.id,
            "asset_name": asset.name,
            "asset_tag_id": asset.tag_id or "",
            "asset_tag_type": asset.tag_type or "",
            "asset_type": asset.type or "",
        }


    @database_sync_to_async
    def create_full_tank_request_row(self, resolved):
        """
        Persist the Full Tank Mode RequestFuelDispensingDetails row using the
        already-validated context produced by
        validate_and_resolve_full_tank_context.
        """
        try:
            row = RequestFuelDispensingDetails.objects.create(
                user_id=resolved["user_id"],
                user_name=resolved["user_name"],
                user_email=resolved["user_email"],
                user_phone=resolved["user_phone"],
                user_tag_id=resolved["user_tag_id"],
                dispenser_gun_mapping_id=resolved["dispenser_gun_mapping_id"],
                dispenser_serialnumber=resolved["dispenser_serialnumber"],
                dispenser_imeinumber=resolved["dispenser_imeinumber"],
                delivery_location_id=resolved["delivery_location_id"],
                delivery_location_name=resolved["delivery_location_name"],
                DU_Accessible_delivery_locations=resolved["DU_Accessible_delivery_locations"],
                customer_id=resolved["customer_id"],
                customer_name=resolved["customer_name"],
                customer_email=resolved["customer_email"],
                customer_phone=resolved["customer_phone"],
                asset_id=resolved["asset_id"],
                asset_name=resolved["asset_name"],
                asset_tag_id=resolved["asset_tag_id"],
                asset_tag_type=resolved["asset_tag_type"],
                asset_type=resolved["asset_type"],
                transaction_id=resolved["transaction_id"],
                dispenser_volume=0.0,
                dispenser_price=0.0,
                dispenser_live_price=0.0,
                request_type=2,        # Full Tank Mode
                request_vehicle=0,     # Asset
                request_status=0,      # Pending
                fuel_state=False,
                transaction_log={},
                remarks="Auto-created from hardware tag scan (msg_type=71)",
                request_created_at=dj_timezone.now(),
                request_created_by=resolved["user_id"],
            )
            return {"row_id": row.id}
        except Exception as e:
            return {"error": f"DB write failed: {e}"}



    @database_sync_to_async
    def save_totalizer_and_gps_starting_with_validation(self, transaction_id, imei, totalizer_vol, totalizer_price, gps_data):
        txn = None
        txn_source = None

        try:
            txn = RequestFuelDispensingDetails.objects.get(transaction_id=transaction_id)
            txn_source = "request"
        except RequestFuelDispensingDetails.DoesNotExist:
            pass
        if txn is None:
            try:
                txn = OrderFuelDispensingDetails.objects.get(transaction_id=transaction_id)
                txn_source = "order"
            except OrderFuelDispensingDetails.DoesNotExist:
                return
        if txn.dispenser_imeinumber != imei:
            return
        dispenser_gun_mapping_id = txn.dispenser_gun_mapping_id
        if txn_source == "request":
            last_txn = (
                RequestFuelDispensingDetails.objects
                .filter(dispenser_gun_mapping_id=dispenser_gun_mapping_id)
                .exclude(id=txn.id)
                .order_by("-request_created_at")
                .first()
            )
        else:
            last_txn = (
                OrderFuelDispensingDetails.objects
                .filter(dispenser_gun_mapping_id=dispenser_gun_mapping_id)
                .exclude(id=txn.id)
                .order_by("-request_created_at")
                .first()
            )
        if last_txn is None:
            totalizer_validation = 0
        else:
            if last_txn.totalizer_price_ending == totalizer_price:
                totalizer_validation = 0
            else:
                totalizer_validation = 1
        txn.totalizer_volume_starting = totalizer_vol
        txn.totalizer_price_starting = totalizer_price
        txn.gps_coordinates_starting = gps_data
        txn.totalizer_validation = totalizer_validation

        txn.save(update_fields=[
            "totalizer_volume_starting",
            "totalizer_price_starting",
            "gps_coordinates_starting",
            "totalizer_validation"
        ])

    @database_sync_to_async
    def update_gps_coordinates(self, imei, gps_data: dict, has_fix: bool):
        try:
            dispenser = DispenserUnits.objects.get(imei_number=imei)
            dispenser_mapping = None
            try:
                dispenser_mapping = Dispenser_Gun_Mapping_To_Customer.objects.get(
                    dispenser_unit=dispenser,
                    assigned_status=True
                )
            except Dispenser_Gun_Mapping_To_Customer.DoesNotExist:
                pass
            if dispenser_mapping is None:
                try:
                    dispenser_mapping = Dispenser_Gun_Mapping_To_Vehicles.objects.get(
                        dispenser_unit=dispenser,
                        assigned_status=True
                    )
                except Dispenser_Gun_Mapping_To_Vehicles.DoesNotExist:
                    return
            current_gps = dispenser_mapping.gps_coordinates or {}

            if has_fix:
                gps_data["live_data"] = True
                dispenser_mapping.gps_coordinates = gps_data
            else:
                if current_gps:
                    current_gps["live_data"] = False
                    dispenser_mapping.gps_coordinates = current_gps
                else:
                    gps_data["live_data"] = False
                    dispenser_mapping.gps_coordinates = gps_data
            dispenser_mapping.save(update_fields=["gps_coordinates"])
        except DispenserUnits.DoesNotExist:
            print(f"[ERROR] Dispenser with IMEI {imei} not found for GPS update")



    @database_sync_to_async
    def update_dispense_transaction_details(self, transaction_id, imei, ppu, volume, money, dispense_time, fuel_time,gvr_money,gvr_volume,user_valid,user_tag_id):
        txn = None

        try:
            txn = RequestFuelDispensingDetails.objects.get(transaction_id=transaction_id)
        except RequestFuelDispensingDetails.DoesNotExist:
            pass
        if txn is None:
            try:
                txn = OrderFuelDispensingDetails.objects.get(transaction_id=transaction_id)
            except OrderFuelDispensingDetails.DoesNotExist:
                return
        if txn.dispenser_imeinumber != imei:
            return {"error": "IMEI mismatch with transaction record."}


        txn.dispenser_live_price = ppu
        txn.dispenser_received_volume = volume
        txn.dispenser_received_price = money
        txn.dispense_end_time = dispense_time
        txn.dispense_time_taken = fuel_time
        txn.totalizer_volume_ending = gvr_volume / 100
        txn.totalizer_price_ending = gvr_money
        txn.user_valid = user_valid
        txn.user_tag_id = user_tag_id
        txn.save(update_fields=[
            "dispenser_live_price",
            "dispenser_received_volume",
            "dispenser_received_price",
            "dispense_end_time",
            "dispense_time_taken",
            "totalizer_volume_ending",
            "totalizer_price_ending",
            "user_valid",
            "user_tag_id"
        ])
        return {"success": True,"request_status": txn.request_status}

    @database_sync_to_async
    def update_fuel_readings(
        self,
        imei,
        fuel_level: float,
        fuel_temperature: float,
        epoch_time: int,
        msg_type: int,
        transaction_id: str = None
    ):
        try:
            dispenser = DispenserUnits.objects.get(imei_number=imei)
        except DispenserUnits.DoesNotExist:
            return

        dispenser_mapping = None
        is_customer = False

        # 1️⃣ Try Customer mapping first
        dispenser_mapping = Dispenser_Gun_Mapping_To_Customer.objects.filter(
            dispenser_unit=dispenser,
            assigned_status=True
        ).first()

        if dispenser_mapping:
            is_customer = True
        else:
            # 2️⃣ Try Vehicle mapping
            dispenser_mapping = Dispenser_Gun_Mapping_To_Vehicles.objects.filter(
                dispenser_unit=dispenser,
                assigned_status=True
            ).first()

        if not dispenser_mapping:
            return

        raw_adc = float(fuel_level)
        calibration_config = dispenser_mapping.fuel_level_sensor_configuration

        points = None
        if calibration_config:
            try:
                if isinstance(calibration_config, str):
                    calibration_config = json.loads(calibration_config)
                points = sorted(
                    calibration_config.get("sensor", {}).get("points", []),
                    key=lambda p: p["code"]
                ) or None
            except Exception:
                calibration_config = None
                points = None

        # Drop sensor error codes and corrupt frames before they reach the
        # calibration curve -- otherwise a fault reads as a real fuel level.
        is_valid, reason = validate_fuel_sample(raw_adc, fuel_temperature, points)
        if not is_valid:
            print(f"[FUEL REJECT] IMEI {imei} msg_type {msg_type}: {reason}")
            return

        if calibration_config:
            try:
                fuel_level = self.convert_adc_to_fuel_level(
                    raw_adc,
                    calibration_config
                )
            except Exception:
                fuel_level = raw_adc
        else:
            fuel_level = raw_adc
        if msg_type == 41:
            FuelSensorReadings.objects.create(
                dispenser_customer_mapping=dispenser_mapping if is_customer else None,
                dispenser_vehicle_mapping=dispenser_mapping if not is_customer else None,
                fuel_level=fuel_level,
                temperature=fuel_temperature,
                data_type=41,
                transaction_id=transaction_id,
                epoch_time=epoch_time
            )
            return

        if msg_type in (31, 4):
            if is_customer:
                last_reading = FuelSensorReadings.objects.filter(
                    dispenser_customer_mapping=dispenser_mapping,
                    data_type__in=[31, 4]
                ).order_by("-epoch_time").first()
            else:
                last_reading = FuelSensorReadings.objects.filter(
                    dispenser_vehicle_mapping=dispenser_mapping,
                    data_type__in=[31, 4]
                ).order_by("-epoch_time").first()

            if not last_reading:
                FuelSensorReadings.objects.create(
                    dispenser_customer_mapping=dispenser_mapping if is_customer else None,
                    dispenser_vehicle_mapping=dispenser_mapping if not is_customer else None,
                    fuel_level=fuel_level,
                    temperature=fuel_temperature,
                    data_type=msg_type,
                    epoch_time=epoch_time
                )
                return
            if (
                abs(float(last_reading.fuel_level) - float(fuel_level)) > 0.01 or
                abs(float(last_reading.temperature) - float(fuel_temperature)) > 0.1
            ):
                FuelSensorReadings.objects.create(
                    dispenser_customer_mapping=dispenser_mapping if is_customer else None,
                    dispenser_vehicle_mapping=dispenser_mapping if not is_customer else None,
                    fuel_level=fuel_level,
                    temperature=fuel_temperature,
                    data_type=msg_type,
                    epoch_time=epoch_time
                )
            else:
                print(f"[FUEL SKIP] No change detected for IMEI {imei}")

    def convert_adc_to_fuel_level(self, adc_value: float, calibration_config: dict):
        try:
            points = calibration_config.get("sensor", {}).get("points", [])
            if not points:
                return adc_value  
            points = sorted(points, key=lambda x: x["code"])

            # Clamps must apply the same decilitre -> litre scaling as the
            # interpolated branch below, otherwise a reading at either end of
            # the curve comes out 10x the value of one just inside it.
            if adc_value <= points[0]["code"]:
                return round(points[0]["value"] / FUEL_LEVEL_SCALE, 2)

            if adc_value >= points[-1]["code"]:
                return round(points[-1]["value"] / FUEL_LEVEL_SCALE, 2)

            for i in range(len(points) - 1):
                p1 = points[i]
                p2 = points[i + 1]

                if p1["code"] <= adc_value <= p2["code"]:
                    x1, y1 = p1["code"], p1["value"]
                    x2, y2 = p2["code"], p2["value"]
                    calibrated_value = (y1 + (
                        (adc_value - x1) * (y2 - y1) / (x2 - x1)
                    )) / FUEL_LEVEL_SCALE

                    return round(calibrated_value, 2)

            return adc_value
        except Exception as e:
            return adc_value

    @database_sync_to_async
    def update_transaction_log(self, data):
        transaction_id = data.get("transaction_id")
        imei = data.get("imei")

        request = None

        try:
            request = RequestFuelDispensingDetails.objects.get(transaction_id=transaction_id)
        except RequestFuelDispensingDetails.DoesNotExist:
            pass

        if request is None:
            try:
                request = OrderFuelDispensingDetails.objects.get(transaction_id=transaction_id)

            except OrderFuelDispensingDetails.DoesNotExist:
                return {"error": "Transaction ID not found"}

        if request.dispenser_imeinumber != imei:
            return {"error": "IMEI mismatch with transaction record."}

        log_data = {
            k: v for k, v in data.items()
            if k not in ["type", "machine", "transaction_id", "imei"]
            }
        if isinstance(request.transaction_log, list):
            request.transaction_log.append(log_data)
        elif request.transaction_log:
            request.transaction_log = [request.transaction_log, log_data]
        else:
            request.transaction_log = [log_data]

        request.save(update_fields=["transaction_log"])
        return {"success": True}

    @database_sync_to_async
    def update_request_status_from_status_code(self, transaction_id: str, imei: str, status_code: int):
        if not transaction_id or not str(transaction_id).strip():
            return {"error": "Transaction ID not found"}
        txn = None

        try:
            txn = RequestFuelDispensingDetails.objects.get(transaction_id=transaction_id)
        except RequestFuelDispensingDetails.DoesNotExist:
            return {"error": "Request Fuel Dispensing ID not found with Transaction ID"}

        if txn is None:
            try:
                txn = OrderFuelDispensingDetails.objects.get(transaction_id=transaction_id)
            except OrderFuelDispensingDetails.DoesNotExist:
                return {"error": "Transaction ID not found"}
        if txn.dispenser_imeinumber != imei:
            return {"error": "Transaction ID not found"}

        if status_code == 200:
            request_status = 1  # Hardware Received
        elif status_code == 0:
            request_status = 0  # Pending
        elif status_code in [201,202, 206]:
            request_status = 2  # Dispensing
        elif status_code in [203,204]:
            request_status = 3  # Completed
        elif status_code == 205:
            request_status = 4  # Interrupted
        elif status_code in [400, 401,402, 410, 411, 420]:
            request_status = 5  # Failed

        else:
            request_status = 5  #Failed

        txn.request_status = request_status
        txn.dispense_status_code = status_code
        txn.save(update_fields=["request_status", "dispense_status_code"])
        return {"success": True,"request_status": request_status}

    @sync_to_async
    def mark_vin_vehicle_status_true(self,txn_id: str):
        try:
            row =VIN_Vehicle.objects.get(transaction_id=txn_id)
            if not row:
                return {"error": f"VIN_Vehicle not found for transaction_id={txn_id}"}
            if getattr(row, "status", None) is not True:
                row.status = True
                row.save(update_fields=["status"])
            return {"ok": True}
        except Exception as e:
            return {"error": f"{type(e).__name__}: {e}"}

    @database_sync_to_async
    def save_obd_gps_reading(self, imei, obd_valid, obd_data, dist_dtc, gps_data, has_fix, epoch_time):
        try:
            dispenser = DispenserUnits.objects.get(imei_number=imei)
        except DispenserUnits.DoesNotExist:
            print(f"[ERROR] Dispenser with IMEI {imei} not found for OBD/GPS save")
            return

        vehicle_mapping = Dispenser_Gun_Mapping_To_Vehicles.objects.filter(
            dispenser_unit=dispenser
        ).first()
        if not vehicle_mapping:
            print(f"[SKIP OBD-GPS] No vehicle mapping for IMEI {imei}")
            return

        if not obd_valid and not has_fix:
            print(f"[SKIP OBD-GPS] IMEI={imei} OBD invalid and no GPS fix — nothing to save")
            return

        live_odometer = None
        saved_obd_data = None

        if obd_valid and dist_dtc is not None:
            odometer_reading = vehicle_mapping.odometer_reading or 0
            if dist_dtc < 0:
                print(f"[SKIP OBD-GPS] IMEI={imei} dist_dtc is negative ({dist_dtc}), skipping odometer update")
            else:
                live_odometer = odometer_reading + dist_dtc
                vehicle_mapping.live_odometer_reading = live_odometer
                vehicle_mapping.save(update_fields=["live_odometer_reading"])
            saved_obd_data = obd_data

        saved_gps_data = gps_data if has_fix else None

        VehicleOBDAndGPSReadings.objects.create(
            dispenser_vehicle_mapping=vehicle_mapping,
            obd_valid=obd_valid,
            obd_data=saved_obd_data,
            live_odometer_reading=live_odometer,
            gps_data=saved_gps_data,
            has_fix=has_fix,
            epoch_time=epoch_time,
        )

    @database_sync_to_async
    def save_gps_ending_and_obd_to_transaction(self, transaction_id, imei, gps_data_ending, obd_valid, obd_data, dist_dtc):
        txn = None

        try:
            txn = RequestFuelDispensingDetails.objects.get(transaction_id=transaction_id)
        except RequestFuelDispensingDetails.DoesNotExist:
            pass
        if txn is None:
            try:
                txn = OrderFuelDispensingDetails.objects.get(transaction_id=transaction_id)
            except OrderFuelDispensingDetails.DoesNotExist:
                print(f"[WARN] No Request or Order found for TXN={transaction_id} to save GPS ending/OBD")
                return
        if txn.dispenser_imeinumber != imei:
            print(f"[WARN] IMEI mismatch for TXN={transaction_id}: expected={txn.dispenser_imeinumber}, got={imei}")
            return

        update_fields = []

        if gps_data_ending is not None:
            txn.gps_coordinates_ending = gps_data_ending
            update_fields.append("gps_coordinates_ending")

        if obd_valid and obd_data is not None:
            txn.obd_data = obd_data
            update_fields.append("obd_data")

            if dist_dtc is not None and dist_dtc >= 0:
                dispenser_gun_mapping_id = txn.dispenser_gun_mapping_id
                vehicle_mapping = Dispenser_Gun_Mapping_To_Vehicles.objects.filter(
                    id=dispenser_gun_mapping_id
                ).first()
                if vehicle_mapping:
                    odometer_reading = vehicle_mapping.odometer_reading or 0
                    live_odometer = odometer_reading + dist_dtc
                    txn.live_odometer_reading = live_odometer
                    update_fields.append("live_odometer_reading")

        if update_fields:
            txn.save(update_fields=update_fields)
            print(f"[TXN OBD-GPS] TXN={transaction_id} updated fields: {update_fields}")